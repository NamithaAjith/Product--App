import { Component, OnInit } from '@angular/core';
import { ProductModel } from './product.model';
import { ProductService} from '../product.service'


@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  title:String = 'Product List';
  products: ProductModel[];
    private id: string;
    Status: String;
    data: any = [];
  

  
  imageWidth : number = 50;
  imageMargin : number = 2;

  showImage :boolean = false

  constructor(private productService: ProductService) { }

  toggleImage():void{
      this.showImage = !this.showImage;
  }
  ngOnInit(){
    this.getProducts();
  }
  
  
  getProducts(){
      this.productService.getProducts().subscribe((data)=>{
        this.products = JSON.parse(JSON.stringify(data));
      })

  }
  deleteClick(id){
    this.productService.deleteProduct(id)
    .subscribe((result) => {
      console.log(result);
      if (JSON.parse(JSON.stringify(result)).Status=="success" ){
        this.getProducts();
      
      }
      else{
        alert('Error');
      }
    });
  }

} 
