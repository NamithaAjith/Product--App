import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductService } from '../product.service';
import { ProductModel } from '../product-list/product.model';

@Component({
  selector: 'app-new-product',
  templateUrl: './new-product.component.html',
  styleUrls: ['./new-product.component.css']
})
export class NewProductComponent implements OnInit {
  title:String = "Add Product";
  private id: string;
  singleProduct: any;
  
  constructor( private productService:ProductService, private router:Router) { }
  productItem = new ProductModel(null,null,null,null,null,null,null,null);

  ngOnInit(){
  }
  AddProduct()
  {
    this.productService.newProduct(this.productItem);
    console.log("Called");
    alert("Success");
    this.router.navigate(['/']);
  }
  updateProduct(){
    this.productService.updateProduct(this.productItem, this.id);
    console.log('product updated');
    alert('product updated');
    this.router.navigate(['/']);
  }
  // id(productItem: ProductModel, id: any) {
  //   throw new Error("Method not implemented.");
  // }

}
